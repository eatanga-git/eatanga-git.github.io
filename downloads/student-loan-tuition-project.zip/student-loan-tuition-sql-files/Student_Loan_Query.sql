CREATE DATABASE student_funding;
USE student_funding;

CREATE TABLE StudentLoanAvg (
academic_year varchar(9) PRIMARY KEY,
loan_avg_amount DECIMAL(10, 2)
);

CREATE TABLE TuitionPrivate(
academic_year VARCHAR(9) PRIMARY KEY,
avg_amount DECIMAL(10, 2)
);

CREATE TABLE TuitionPublic (
academic_year VARCHAR(9) PRIMARY KEY,
avg_amount DECIMAL(10,2)
);

/*Compare Avg Loan amount vs private and public tuition amount*/
SELECT s.academic_year,
	s.loan_avg_amount AS avg_student_loan,
    p.avg_amount AS private_tuition,
    u.avg_amount AS public_tuition
    
FROM StudentLoanAvg s
LEFT JOIN TuitionPrivate p ON s.academic_year = p.academic_year
LEFT JOIN TuitionPublic u ON s.academic_year = u.academic_year;

/*Years where loan covered less than 50% of tuition*/
SELECT s.academic_year,
	s.loan_avg_amount,
	p.avg_amount AS private_tution,
    u.avg_amount AS public_tuition,
    CASE 
        WHEN s.loan_avg_amount < (p.avg_amount * 0.5) THEN 'Below 50%'
        WHEN s.loan_avg_amount >= (p.avg_amount * 0.5) THEN 'Above 50%'
        ELSE 'No Data'
    END AS private_loan_coverage,
    CASE 
        WHEN s.loan_avg_amount < (u.avg_amount * 0.5) THEN 'Below 50%'
        WHEN s.loan_avg_amount >= (u.avg_amount * 0.5) THEN 'Above 50%'
        ELSE 'No Data'
    END AS public_loan_coverage
FROM StudentLoanAvg s
LEFT JOIN TuitionPrivate p ON s.academic_year = p.academic_year
LEFT JOIN TuitionPublic u ON s.academic_year = u.academic_year;

/*year over year increase*/
SELECT s1.academic_year,
	s1.loan_avg_amount AS current_year_loan,
    s2.loan_avg_amount AS prev_year_loan,
    (s1.loan_avg_amount - s2.loan_avg_amount) AS loan_difference,
    ROUND(((s1.loan_avg_amount - s2.loan_avg_amount)/ s2.loan_avg_amount) * 100, 2) AS pct_change
FROM StudentLoanAvg s1
LEFT JOIN StudentLoanAvg s2
	ON LEFT (s1.academic_year, 4) = CAST(LEFT(s2.academic_year, 4)+ 1 AS CHAR)
ORDER BY s1.academic_year;

/*Student loan coverage ratio*/
SELECT s.academic_year, 
       s.loan_avg_amount, 
       p.avg_amount AS private_tuition, 
       u.avg_amount AS public_tuition,
       ROUND((s.loan_avg_amount / p.avg_amount) * 100, 2) AS private_coverage_percent,
       ROUND((s.loan_avg_amount / u.avg_amount) * 100, 2) AS public_coverage_percent
FROM StudentLoanAvg s
LEFT JOIN TuitionPrivate p ON s.academic_year = p.academic_year
LEFT JOIN TuitionPublic u ON s.academic_year = u.academic_year;

/*Year with largest private tuition increase*/
SELECT academic_year, avg_amount AS tuition, 
       avg_amount - LAG(avg_amount) OVER (ORDER BY academic_year) AS tuition_increase
FROM TuitionPrivate
ORDER BY tuition_increase DESC
LIMIT 1;

/*Year with largest public tuition increase*/
SELECT academic_year, avg_amount AS tuition, 
       avg_amount - LAG(avg_amount) OVER (ORDER BY academic_year) AS tuition_increase
FROM TuitionPublic
ORDER BY tuition_increase DESC
LIMIT 1;

/*public tuition year over year increase*/
SELECT t1.academic_year,
       t1.avg_amount AS current_year_public_tuition,
       t2.avg_amount AS prev_year_public_tuition,
       (t1.avg_amount - t2.avg_amount) AS tuition_difference,
       ROUND(((t1.avg_amount - t2.avg_amount) / t2.avg_amount) * 100, 2) AS pct_change
FROM TuitionPublic t1
LEFT JOIN TuitionPublic t2
    ON LEFT(t1.academic_year, 4) = CAST(LEFT(t2.academic_year, 4) + 1 AS CHAR)
ORDER BY t1.academic_year;

/*private tuition year over year increase*/
SELECT t1.academic_year,
       t1.avg_amount AS current_year_private_tuition,
       t2.avg_amount AS prev_year_private_tuition,
       (t1.avg_amount - t2.avg_amount) AS tuition_difference,
       ROUND(((t1.avg_amount - t2.avg_amount) / t2.avg_amount) * 100, 2) AS pct_change
FROM TuitionPrivate t1
LEFT JOIN TuitionPrivate t2
    ON LEFT(t1.academic_year, 4) = CAST(LEFT(t2.academic_year, 4) + 1 AS CHAR)
ORDER BY t1.academic_year;
