CREATE TABLE loan_average (
	academic_year CHAR,
    loan_amt INT
);