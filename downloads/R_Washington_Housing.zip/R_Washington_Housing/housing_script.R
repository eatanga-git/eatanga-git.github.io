install.packages("dplyr")
library(dplyr)

housing <- read.csv("USA Housing Dataset.csv")
View(housing)

#Lets view the variables for the dataset.
summary(housing)
sapply(housing, class)

#removing missing and duplicate
housing <- na.omit(housing)
housing <- housing  %>% distinct()
summary(housing)

#No missing data or duplicates

#Scatter plot by 
plot(housing$bedrooms, housing$price, pch=16, cex=1)
#we see some outliers for the 3 bedroom size for prices
#price also seems to level off at 5-6 bedrooms. 
#seems like bedrooms after 6 doesn't increase much

plot(housing$sqft_living, housing$price, pch=16, cex=1)
#seems like outside of a few outliers with 200 sq ft,
#there is a gradual increase in price the more sq ft increases

plot(housing$yr_built, housing$price)
#seems to be weak correlation. Maybe due to renovations?


#Plot to show top 5 cities
#top5cities <- tail(sort(housing$city), 5)
top_cities <- housing %>%
  group_by(city, statezip) %>%
  summarise(AveragePrice = mean(price, na.rm = TRUE)) %>%
  arrange(desc(AveragePrice)) %>%
  head(5)

top_cities

labels <- paste(top_cities$city, top_cities$statezip, sep=", ")
barplot(top_cities$AveragePrice, names.arg=labels, col = "steelblue", las = 2,
        main = "Top 5 Cities by Average Housing Price",
        xlab = "City, State", ylab = "Average Price")

#Washington has most expensive housing




#we will have to encode some categorical variables.
#Let's see how many cities and state zip codes there are.

unique(housing$city)
unique(housing$statezip)
#There are 41 unique cities and 73 unique state zip codes. This is a lot,
#So one-hot encoding may be impractical.
# since the cities are all in washington, we can drop city and state for now,
#and use clustering later.

#The same issue exists with dates
unique(housing$date)

#Lets drop city, statezip, country, and date for now. Ideally we would
#group date by decade. But based on our graph, date didn't seem to make too much
# of a difference.

new_housing <- subset(housing, select = -c(`date`, `city`, `statezip`, `street`, `country`))

sapply(new_housing, class)

#Lets scale the data


#We will install caTools in order to split our data
install.packages('caTools')
library(caTools)

#Now we will train the model
set.seed(123)
split = sample.split(new_housing$price, SplitRatio = 0.8)
training_set = subset(new_housing, split == TRUE)
test_set = subset(new_housing, split == FALSE)

#Feature Scaling
ntraining_set = scale(training_set)
ntest_set = scale(test_set)

scaled_training <- ntraining_set
scaled_training[, -which(names(ntraining_set) == "Price")] <- as.data.frame(scale(training_set[, -which(names(training_set) == "Price")]))

regressor <- lm(formula = price ~., data = scaled_training )

summary(regressor)

# Because our R^2 isn't good, we will cluster the data instead.

# Select only numeric columns (excluding IDs, if any)
housing_numeric <- training_set %>%
  select_if(is.numeric) %>%
  na.omit()  # Remove missing values if needed

# Scale the data to ensure equal weighting
housing_scaled <- scale(housing_numeric)


library(factoextra)
fviz_nbclust(housing, kmeans, method="wss")

set.seed(123)
kmeans_result <- kmeans(housing_scaled, centers= 3, nstart=25)
training_set$Cluster <- as.factor(kmeans_result$cluster)

aggregate(training_set[, c("price", "sqft_living", "bedrooms", "bathrooms", "floors")], 
          by = list(Cluster = training_set$Cluster), 
          mean)

library(ggplot2)

ggplot(training_set, aes(x = sqft_living, y = price, color = Cluster)) +
  geom_point() +
  theme_minimal() +
  labs(title = "Housing Clusters by Price and Size")

 
#Conclusion - A better estimate can be obtained by utilizing an API access key for the Census.gov data.